import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
void main() {
  runApp(const MyApp());
}
class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

void fetchAllMovies()async{
 final res =await http.get(Uri.parse("http://nizomiddin96.pythonanywhere.com/api/v1/movie/"));
 if(res.statusCode==200){
 final result= jsonDecode(res.body);
 Iterable list = result["Movies"];
 }
}

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Movies App",
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Movies'),
        ),
        body: Container(

        ),
      ),
    );
  }
}
