class Movie{
  final int id;
  final String title;
  final String tagLine;
  final String category;
  final bool rating_user;
  final String middle_star;
  final String poster;

  Movie(this.id, this.title, this.tagLine, this.category, this.rating_user,
      this.middle_star, this.poster);
  factory Movie.fromJson(Map<String, dynamic> json){
    return Movie(id: json["Id"],
        tagLine: json["TagLine"],
        category: json["Category"],
        rating_user: json["Rating_user"],
        middle_star: json["Middle_star"],
        poster: json["poster"];
    );
  }
}